#include <stdio.h>
#include "pile.h"

int main(void) 
{

  /* a completer ... */

	return 0;
}
