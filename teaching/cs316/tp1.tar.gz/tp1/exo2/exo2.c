#include <stdio.h>
#include "file.h"

int main(void) 
{

  /* a complete ... */

	return 0;
}
