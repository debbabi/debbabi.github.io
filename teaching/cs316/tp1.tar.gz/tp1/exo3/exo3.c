#include <stdio.h>
#include "liste.h"

int main(void) 
{

  /* a completer ... */

	return 0;
}
