package ProjetCompil.Verif.Src;

/**
 * Exception levée en cas d'erreur interne dans ReglesTypage.
 */

public class ErreurReglesTypage extends RuntimeException { }

